export default async (req) => {
  if (req.method !== "POST") return new Response(JSON.stringify({error:"Use POST"}), {status:405,headers:{"Content-Type":"application/json"}});
  const expectedCode = process.env.JARVIS_ACCESS_CODE || "";
  const suppliedCode = req.headers.get("x-jarvis-code") || "";
  if (expectedCode && suppliedCode !== expectedCode) return new Response(JSON.stringify({error:"Enter the correct private access code in the dashboard"}), {status:401,headers:{"Content-Type":"application/json"}});
  const key = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
  if (!key) return new Response(JSON.stringify({error:"OPENAI_API_KEY is not configured in the hosting environment"}), {status:503,headers:{"Content-Type":"application/json"}});
  try {
    const {message} = await req.json();
    if (typeof message !== "string" || !message.trim() || message.length > 4000) return new Response(JSON.stringify({error:"Message must be 1–4000 characters"}), {status:400,headers:{"Content-Type":"application/json"}});
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model,
        instructions:"You are JARVIS, the user's practical personal assistant on Android. Be clear, useful, concise and honest. Do not claim to perform phone actions you cannot perform. Help with study planning and authorized cybersecurity learning. Ask before consequential actions.",
        input:message,
        max_output_tokens:700
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return new Response(JSON.stringify({error:data?.error?.message || `AI provider returned ${upstream.status}`}), {status:502,headers:{"Content-Type":"application/json"}});
    const reply = (data.output || []).flatMap(x => x.type === "message" ? (x.content || []).filter(c => c.type === "output_text").map(c => c.text) : []).join("\n").trim();
    return new Response(JSON.stringify({reply:reply || "I received an empty response."}), {status:200,headers:{"Content-Type":"application/json"}});
  } catch (e) {
    return new Response(JSON.stringify({error:"Invalid request or upstream connection failed"}), {status:500,headers:{"Content-Type":"application/json"}});
  }
};
