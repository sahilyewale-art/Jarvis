# JARVIS Android PWA starter

This is an installable web app (PWA), not a compiled APK. It has a futuristic mobile interface, browser speech recognition/synthesis, quick links, and a serverless AI endpoint. The API key is stored on the hosting provider, not in the phone's JavaScript.

## Easiest deployment path (requires one-time setup)
1. Create a GitHub account if needed, then create a new repository named `jarvis-android`.
2. Upload all files and folders inside the extracted `JARVIS_PWA_Starter` folder to the repository root, preserving folder paths (including `public` and `netlify`). GitHub's web interface supports **Add file → Upload files**.
3. Create a Netlify account at https://app.netlify.com/ and choose **Add new site → Import an existing project**. Connect GitHub and select `jarvis-android`.
4. Netlify should detect `netlify.toml`. Deploy the site.
5. In Netlify site settings, open **Environment variables** and add:
   - `OPENAI_API_KEY` = your API key
   - `OPENAI_MODEL` = `gpt-4.1-mini` (or a model available to your API account)
   - `JARVIS_ACCESS_CODE` = a long private code of your choice (recommended; enter it in the app dashboard)
6. Trigger a new deploy so the function receives the variables.
7. Open the deployed HTTPS site on your Android phone in Chrome. Use the three-dot menu → **Install app** or **Add to Home screen**.

## Important
- API usage is billed separately from ChatGPT plans.
- Never put an API key in `index.html` or any client-side file. Add it only as a private Netlify environment variable.
- Configure `JARVIS_ACCESS_CODE` in Netlify to require a shared access code before the AI endpoint will answer. Enter that code in the dashboard and tap Save. This is a basic shared-code gate, not full account authentication or rate limiting; keep the URL private and monitor API usage.
- Voice input support varies by browser and language. It starts only when the user taps the microphone.
- This PWA cannot control arbitrary Android apps, phone settings, SMS, or calls. That requires a native Android app and Android permissions.
- If you don't want cloud hosting/API setup, the earlier Termux package runs locally but has more manual installation steps.
